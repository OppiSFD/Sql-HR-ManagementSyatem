﻿/*

					 SQL Project Name : HR Managment System
					Trainee Name : Meherab Hossain  
					Trainee ID : 1280472  
				 Batch ID : CS/PNTL-M/58/01 

 --------------------------------------------------------------------------------
Table of Contents: DML

			 ‣SECTION   01  : INSERT DATA USING INSERT INTO KEYWORD
			 ‣SECTION   02  : SELECT FROM TABLE
			 ‣SECTION	03	: SELECT FROM VIEW
			 ‣SECTION	04	: SELECT INTO
			 ‣SECTION	05	: INNER JOIN WITH GROUP BY CLAUSE
			 ‣SECTION	06	: INNER JOIN
			 ‣SECTION	07	: LEFT JOIN
			 ‣SECTION	08	: CROSS JOIN
			 ‣SECTION	09	: TOP DISTINCT CLAUSE WITH TIES
			 ‣SECTION	10	: COMPARISON, LOGICAL(AND OR NOT) & BETWEEN OPERATOR
			 ‣SECTION	11	: LIKE, IN, NOT IN, OPERATOR & IS NULL CLAUSE
			 ‣SECTION	12	: OFFSET FETCH
			 ‣SECTION	13	: AGGREGATE FUNCTIONS
			 ‣SECTION	14	: ROLLUP & CUBE OPERATOR
			 ‣SECTION	15	: INSERT,UPDATE,DELETE STORE PROCEDURE
			 ‣SECTION	16	: COALESCE & ISNULL
			 ‣SECTION	17	: HAVING
			 ‣SECTION	18	: ANY,SOME, ALL
*/

 /*
==============================  SECTION 01  ==============================
					INSERT DATA USING INSERT INTO KEYWORD
========================================================================== 
*/

USE HMS
GO
Insert Into Department Values
(1,'HR'),
(2,'IT'),
(3,'Sales')
GO
INSERT INTO Employee values
(1,'John Doe','Male',50000.00,'3-4-23','HR',1),
(2,'Jasmin','Female',56000.00,'5-5-22','IT',2),
(3,'Alice Johnson','Male',40000.00,'10-12-21','Sales',3)
GO
INSERT INTO Project values
(1,'HR PROJECT','30-10-2017','28-5-23'),
(2,'IT PROJECT','18-9-23','19-11-23'),
(3,'SALES PROJECT','14-3-20','18-5-23')
GO

      --------------------- ‣ SECTION   02  : SELECT FROM TABLE


SELECT * FROM Employee 
GO

         -------------- ‣ SECTION   03 : SELECT FROM View 


SELECT * FROM View_ Employee
GO

             ------------ -- ‣SECTION	04	: SELECT INTO

SELECT * INTO EmployeeName  FROM Employee
GO

              ------ ‣SECTION	05	: INNER JOIN WITH GROUP BY CLAUSE

---

        -----‣SECTION	06	: INNER JOIN
	
Select e.id,e.name,e.hireDate,d.department,
Inner join department d.on e.departmentID= d.Id From employee
GO

               ------- ‣SECTION	07	: LEFT JOIN
Select e.id,e.name,e.hireDate,d.department,
Inner join department d.on e.departmentID= d.Id From employee
GO

       -------  ‣SECTION	08	: CROSS JOIN

Select e.id,e.name,e.gender,e.hiredate,d.department cross join department d From employee e
GO

            -----  ‣SECTION	09	: TOP DISTINCT CLAUSE WITH TIES

Select DISTINCT departmentName From department
GO

SELECT TOP 10 * From departmentID
GO

SELECT TOP10 * FROM depatment Order BY depatment DESC
GO

      --------  ‣SECTION	10	: COMPARISON, LOGICAL(AND OR NOT) & BETWEEN OPERATOR

Select * FROM Employee
WHERE EmployeeID = 1 AND Gender = 'MALE'
GO
SELECT * Employee
WHERE EmployeeID =2 OR Gender = 'MALE'
GO
SELECT * FROM Employee
WHERE NOT Gender = 'Female' 
GO
                --- ‣SECTION	11	: LIKE, IN, NOT IN, OPERATOR & IS NULL CLAUSE

Select * FROM Employee
WHERE EmployeeName LIKE '%Alice John',
GO

Select * FROM Employee
WHERE EmployeeName LIKE 'N[A-J]',
GO
Select * FROM Employee
WHERE EmployeeName LIKE 'B[^C-E]'
GO

      --------  ‣SECTION	12	: OFFSET FETCH
Select * FROM Employee
Order by Department
Offset 4 Rows
Fetch Next 4 Rows Only
GO

                    ------- ‣SECTION	13	: AGGREGATE FUNCTIONS
SELECT Department, sum(salary)'Total Salary' * from Employee
Group by Department
GO

      ------- ‣SECTION	14	: ROLLUP & CUBE OPERATOR
SELECT Department, sum(salary)'Total Salary' * from Employee
Group by ROLLUP (Department)
GO

SELECT Department, sum(salary)'Total Salary' * from Employee
Group by CUBE(Department)
GO

     ------- ‣SECTION	15	: INSERT,UPDATE,DELETE STORE PROCEDURE

EXEC SpemployeeINFO 'INSERT', 10, 'RONY','MALE', 60000.00, '11-8-2021','ACCOUNT OFFICER',1, @I OUTPUT
DECLARE @I INT
GO
EXEC SpemployeeInfo 'UPDATE',1,'NOKIYA','MALE',25000.00, '25-5-2023','26-11-23',1,NULL
GO
SELECT @ I
EXEC SpemployeeInfo 'DELETE',2,NULL
GO
         ------- ‣SECTION	16	: COALESCE & ISNULL

SELECT COALESCE (Department,'All Department') AS Department * from Employee AS 'Salary Sum'
Group by ROLLUP (Department)
GO

                ----- ‣SECTION	17	: HAVING

SELECT Department, sum(salary) * from Employee
Group by ROLLUP Department
HAVING SUM (Salary)>50000
GO

    ----- ‣SECTION	18	: ANY,SOME, ALL

IF 2>ANY(SELECT Department FROM Department)
PRINT 'YES'
 ELSE
  PRINT 'NO'
GO
--SOME
IF 2>SOME(SELECT Department FROM Department)
PRINT 'YES'
 ELSE
  PRINT 'NO'
GO
--ALL
IF 2>ALL(SELECT Department FROM Department)
PRINT 'YES'
 ELSE
  PRINT 'NO'
GO

-----------------------------THE END-------