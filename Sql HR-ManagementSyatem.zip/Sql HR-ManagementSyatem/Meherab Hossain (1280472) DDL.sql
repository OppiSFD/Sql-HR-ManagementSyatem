/*
					SQL Project Name : HR Management System
					Trainee Name : Meherab Hossain 
					Trainee ID : 1280472   
					Batch ID : CS/PNTL-M/58/01 

 ---------------------------------------------------------------------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------------

Table of Contents: DDL
			 SECTION 01: Created a Database HMS
			 SECTION 02: Created Appropriate Tables with column definition related to the project
			 SECTION 03: ALTER, DROP AND MODIFY TABLES & COLUMNS
			 SECTION 04: CREATE CLUSTERED AND NONCLUSTERED INDEX
			 SECTION 05: CREATE SEQUENCE & ALTER SEQUENCE
			 SECTION 06: CREATE A VIEW & ALTER VIEW
			 SECTION 07: CREATE STORED PROCEDURE & ALTER STORED PROCEDURE
			 SECTION 08: CREATE FUNCTION(SCALER VALUED FUNCTION & TABLE VALUED FUNCTION)
			 SECTION 09: CREATE TRIGGER (FOR/AFTER TRIGGER)
			 SECTION 10: CREATE TRIGGER (INSTEAD OF TRIGGER)
*/
							
							--  SECTION 01: Created a Database HMS--
CREATE DATABASE HMS
ON
(
	Name='HMS.mdf',
	Filename='D:\Course\SQL\Project\HMS.mdf',
	Size= 5 MB,
	Maxsize= 500 MB,
	Filegrowth= 10%
)
Log ON
(
	Name='HMS.ldf',
	Filename='D:\Course\SQL\Project\HMS.ldf',
	Size= 5 MB,
	Maxsize= 1 GB,
	Filegrowth= 6 MB
)
GO
USE HMS
GO
           ----- SECTION 02: Created Appropriate Tables with column definition related to the project---

Create Table Department
(
    Id int Primary key,
	[Name] varchar (30)
)
GO
Create Table Employee
(
   EmployeeId Int Unique,
   [Name] Nvarchar(30) Not Null,
   Gender varchar(10) Not Null,
   Salary Money Null,
   HireDate DATE Not Null,
   Department varchar(30) Not Null,
   department_ID Int REFERENCES Department(department_ID)
)
GO
Create Table Project
(
    Id INT Primary key,
	[Name] varchar(30) Not Null,
	StartDate DATE NOT NULL,
	EndDate DATE Not Null
)
GO

     ------- SECTION 03: ALTER, DROP AND MODIFY TABLES & COLUMNS--

ALTER TABLE Project
add [name] varchar(30)
GO

ALTER TABLE Employee
ALTER COLUMN Salary Money
GO

Drop Table Project
GO
       ---------- -- SECTION 04: CREATE CLUSTERED AND NONCLUSTERED INDEX----

Create INDEX IX_ EmployeeId on Employee(EmployeeId)
GO

CREATE NONCLUSTERED INDEX IX_ProjectName on ProjectName
GO


     ----------- --  SECTION 05: CREATE SEQUENCE & ALTER SEQUENCE---
CREATE SEQUENCE Seq_2
    START WITH 100  
    INCREMENT BY 3
GO

ALTER SEQUENCE Seq_5 
RESTART WITH 400
GO

    ------------ -- - -SECTION 06: CREATE A VIEW & ALTER VIEW --

CREATE VIEW View_Employee
AS
SELECT EmployeeId,[Name],Gender FROM Employee
GO

 ALTER VIEW View_Employee
AS
SELECT EmployeeId,[Name],Salary FROM Employee
GO

       ----------------- SECTION 07: CREATE STORED PROCEDURE (Insert ,Update,Delete using stored procedure)---

Create Proc SpemployeeInfo @action varchar(10),
                           @Id Int,
						   @Name varchar(30),
						   @Gender varchar(10),
						   @Salary Money,
						   @Hiredate Date,
						   @Department Varchar(30),
						   @OutPut INT Output
AS
BEGIN
      IF @action='INSERT'
	  BEGIN
	      Insert INTO Employee values
		  (@Id,@Name,@Gender,@Salary,@Hiredate,@Department)
		  set @update =@Id
	  END
	  IF @action='Update'
	  BEGIN
	    Update Employee 
		set Name = @Name,
		Gender=@Gender,
		Salary=@Salary, 
		HireDate=@Hiredate,
		Department=@Department
		Where EmployeeId=@Id
		set @Update=@Id
	  END
	  IF @action = 'DELETE'
	  BEGIN
	      DELETE FROM Employee
		  WHERE id=@id
		  set @Update = @Id
	  END

END
GO

     ---------------------  SECTION 08: CREATE FUNCTION(SCALER VALUED FUNCTION & TABLE VALUED FUNCTION)--

 CREATE FUNCTION fnEmployee (@Name varchar(30),
							   @Salary Money,
							   @Department varchar(30))
RETURNS MONEY
AS
BEGIN
		DECLARE @Salary Money
		SET @Salary=@Salary*@Department
		RETURN @Salary
END
GO
Select * From Employee
GO

                                  -------- SECTION 09: CREATE TRIGGER (FOR/AFTER TRIGGER)---

Create Trigger trUpdateDelete_1
on Employee
For Update,Delete
AS
BEGIN
     PRINT 'Not Possible to Update and Delete date!!!!'
	 ROLLBACK Transtion
END
GO
UPDATE Employee SET EmployeeHireDate='10-12-23' WHERE EmployeeId=1
DELETE FROM Employee WHERE EmployeeId=2
GO

                      --- SECTION 10: CREATE TRIGGER (INSTEAD OF TRIGGER)--
Create Trigger trProject
on Project
Instead Of Insert
AS
BEGIN
   Insert Into Project (ProjectID,[Name],'StartDate','EndDate')
   Selete ProjectId,[Name],StartDate,EndDate, from inserted
END
GO
INSERT into Project (ProjectId,[Name],StartDate,EndDate)  values
(4,'Oppi','15-1-23','5-12-23')
GO

                                  -- The End------








 

  
			





